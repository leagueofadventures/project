import pygame
import pytmx
from pytmx import util_pygame

# Инициализация Pygame
pygame.init()

# Полноэкранный режим
flags = pygame.FULLSCREEN | pygame.HWSURFACE | pygame.DOUBLEBUF
screen = pygame.display.set_mode((0, 0), flags)

# Получение размеров экрана
info = pygame.display.Info()
width, height = info.current_w, info.current_h

# Загрузка TMX-карты
map_file = 'безымянный.tmx'  # Замените на путь к вашей карте
tmx_data = util_pygame.load_pygame(map_file)

# Размеры карты
map_width = tmx_data.width * tmx_data.tilewidth
map_height = tmx_data.height * tmx_data.tileheight

# Камера
camera_x = 0
camera_y = 0
camera_speed = 10

# Загрузка спрайта
sprite_path = 'lena.jpg'  # Замените на путь к вашему спрайту
sprite = pygame.image.load(sprite_path)
sprite_rect = sprite.get_rect(center=(width // 2, height // 2))

# Позиция персонажа
player_x = width // 2
player_y = height // 2
player_speed = 5

def draw_map(surface, camera_x, camera_y):
    for layer in tmx_data.visible_layers:
        if isinstance(layer, pytmx.TiledTileLayer):
            for x, y, gid in layer:
                tile = tmx_data.get_tile_image_by_gid(gid)
                if tile:
                    surface.blit(tile, (x * tmx_data.tilewidth - camera_x,
                                        y * tmx_data.tileheight - camera_y))

running = True
while running:
    clock = pygame.time.Clock()
    clock.tick(60)  # Ограничение FPS до 60 кадров в секунду

    # Обработка событий
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    # Управление персонажем
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player_x -= player_speed
    if keys[pygame.K_RIGHT]:
        player_x += player_speed
    if keys[pygame.K_UP]:
        player_y -= player_speed
    if keys[pygame.K_DOWN]:
        player_y += player_speed

    # Проверяем, чтобы персонаж не выходил за пределы карты
    player_x = max(0, min(player_x, map_width - sprite_rect.width))
    player_y = max(0, min(player_y, map_height - sprite_rect.height))

    # Синхронизация камеры с положением персонажа
    camera_x = max(0, min(player_x - (width // 2), map_width - width))
    camera_y = max(0, min(player_y - (height // 2), map_height - height))

    # Отрисовка карты
    screen.fill((0, 0, 0))  # Очистка экрана
    draw_map(screen, camera_x, camera_y)

    # Отрисовка спрайта
    screen.blit(sprite, (player_x - camera_x, player_y - camera_y))
    
    pygame.display.flip()  # Обновление экрана

pygame.quit()
