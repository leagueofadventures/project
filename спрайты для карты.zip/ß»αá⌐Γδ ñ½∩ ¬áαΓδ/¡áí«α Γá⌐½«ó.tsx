<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="набор тайлов" tilewidth="64" tileheight="64" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../Downloads/трава (2).jpg" width="64" height="64"/>
 </tile>
 <tile id="1">
  <image source="../Downloads/дерево.jpg" width="64" height="64"/>
 </tile>
 <tile id="2">
  <image source="../Downloads/камень.png" width="64" height="64"/>
 </tile>
 <tile id="5">
  <image source="../Downloads/пруд (1) (1).jpg" width="64" height="64"/>
 </tile>
</tileset>
