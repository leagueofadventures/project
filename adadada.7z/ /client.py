import pygame
import pytmx
from pytmx import util_pygame
import socket
import pickle
import sys

# Инициализация Pygame
pygame.init()
pygame.display.init()

# Полноэкранный режим
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

# Получение размеров экрана
info = pygame.display.Info()
width, height = info.current_w, info.current_h

# # Загрузка TMX-карты
# map_file = 'безымянный.tmx'
# tmx_data = pytmx.load_pygame(map_file)

# Размеры карты
# map_width = tmx_data.width * tmx_data.tilewidth
# map_height = tmx_data.height * tmx_data.tileheight

# Камера
camera_x = 0
camera_y = 0

camera_speed = 10

# Загрузка спрайта
sprite_path = 'lena.jpg'
# sprite = pygame.image.load(sprite_path)
# sprite_rect = sprite.get_rect(center=(width // 2, height // 2))

# Позиция персонажа
player_x = width // 2
player_y = height // 2
player_speed = 5

# Мультиплеер переменные
players = {}
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    client_socket.connect(('localhost', 5555))
    print("Подключено к серверу")
except:
    print("Не удалось подключиться к серверу")
    pygame.quit()
    sys.exit()

def draw_map(surface, camera_x, camera_y):
    for layer in tmx_data.visible_layers:
        if isinstance(layer, pytmx.TiledTileLayer):
            for x, y, gid in layer:
                tile = tmx_data.get_tile_image_by_gid(gid)
                if tile:
                    surface.blit(tile, (x * tmx_data.tilewidth - camera_x,
                                        y * tmx_data.tileheight - camera_y))

running = True
while running:
    clock = pygame.time.Clock()
    clock.tick(60)

    # Обработка событий
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    # Отправляем вводы на сервер
    keys = pygame.key.get_pressed()
    inputs = {
        'left': keys[pygame.K_LEFT],
        'right': keys[pygame.K_RIGHT],
        'up': keys[pygame.K_UP],
        'down': keys[pygame.K_DOWN]
    }
    try:
        client_socket.send(pickle.dumps(inputs))
        data = client_socket.recv(1024)
        all_positions = pickle.loads(data)
        # Обновляем позиции
        player_x = all_positions['server']['x']
        player_y = all_positions['server']['y']
        players = {k: v for k, v in all_positions.items() if k != 'server'}
    except:
        running = False

    # Синхронизация камеры с положением персонажа
    camera_x = max(0, min(player_x - (width // 2), map_width - width))
    camera_y = max(0, min(player_y - (height // 2), map_height - height))

    # Отрисовка карты
    # screen.fill((0, 0, 0))
    # draw_map(screen, camera_x, camera_y)

    # Отрисовка спрайта сервера
    # screen.blit(sprite, (player_x - camera_x, player_y - camera_y))

    # Отрисовка других игроков
    for pid, pos in players.items():
        screen.blit(sprite, (pos['x'] - camera_x, pos['y'] - camera_y))
    
    pygame.display.flip()

client_socket.close()
pygame.quit()
