import pygame
import pytmx
from pytmx import util_pygame
import socket
import threading
import pickle
import sys

# Режим игры: server или client
if len(sys.argv) > 1:
    mode = sys.argv[1]
else:
    mode = 'single'  # По умолчанию одиночная игра

# Инициализация Pygame
pygame.init()
pygame.display.init()

# Полноэкранный режим
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

# Получение размеров экрана
info = pygame.display.Info()
width, height = info.current_w, info.current_h

# Загрузка TMX-карты
map_file = 'безымянный.tmx'  # Замените на путь к вашей карте
tmx_data = util_pygame.load_pygame(map_file)

# Размеры карты
map_width = tmx_data.width * tmx_data.tilewidth
map_height = tmx_data.height * tmx_data.tileheight

# Камера
camera_x = 0
camera_y = 0
camera_speed = 10

# Загрузка спрайта
sprite_path = 'lena.jpg'  # Замените на путь к вашему спрайту
sprite = pygame.image.load(sprite_path)
sprite_rect = sprite.get_rect(center=(width // 2, height // 2))

# Позиция персонажа
player_x = width // 2
player_y = height // 2
player_speed = 5

# Мультиплеер переменные
players = {}  # {client_id: {'x': x, 'y': y}}
client_id = 0
server_socket = None
client_socket = None
network_thread = None




class bulet():
    def __init__(self, dmg, spead):
        dmg = dmg
        spead = spead
    


if mode == 'server':
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 5555))
    server_socket.listen(5)
    print("Сервер запущен на порту 5555")
elif mode == 'client':
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('localhost', 5555))
    print("Подключено к серверу")

def draw_map(surface, camera_x, camera_y):
    for layer in tmx_data.visible_layers:
        if isinstance(layer, pytmx.TiledTileLayer):
            for x, y, gid in layer:
                tile = tmx_data.get_tile_image_by_gid(gid)
                if tile:
                    surface.blit(tile, (x * tmx_data.tilewidth - camera_x,
                                        y * tmx_data.tileheight - camera_y))

def handle_client(client_sock, addr):
    global client_id
    cid = client_id
    client_id += 1
    players[cid] = {'x': width // 2, 'y': height // 2}
    print(f"Клиент {cid} подключен: {addr}")
    try:
        while running:
            data = client_sock.recv(1024)
            if not data:
                break
            inputs = pickle.loads(data)
            # Обновляем позицию клиента
            if inputs['left']:
                players[cid]['x'] -= player_speed
            if inputs['right']:
                players[cid]['x'] += player_speed
            if inputs['up']:
                players[cid]['y'] -= player_speed
            if inputs['down']:
                players[cid]['y'] += player_speed
            # Ограничиваем позицию
            players[cid]['x'] = max(0, min(players[cid]['x'], map_width - sprite_rect.width))
            players[cid]['y'] = max(0, min(players[cid]['y'], map_height - sprite_rect.height))
            # Отправляем все позиции
            all_positions = {'server': {'x': player_x, 'y': player_y}}
            all_positions.update(players)
            client_sock.send(pickle.dumps(all_positions))
    except:
        pass
    print(f"Клиент {cid} отключен")
    del players[cid]
    client_sock.close()

def server_loop():
    while running:
        try:
            client_sock, addr = server_socket.accept()
            threading.Thread(target=handle_client, args=(client_sock, addr)).start()
        except:
            break

if mode == 'server':
    network_thread = threading.Thread(target=server_loop)
    network_thread.start()

running = True
while running:
    clock = pygame.time.Clock()
    clock.tick(60)  # Ограничение FPS до 60 кадров в секунду

    # Обработка событий
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    if mode == 'client':
        # Отправляем вводы на сервер
        keys = pygame.key.get_pressed()
        inputs = {
            'left': keys[pygame.K_LEFT],
            'right': keys[pygame.K_RIGHT],
            'up': keys[pygame.K_UP],
            'down': keys[pygame.K_DOWN]
        }
        try:
            client_socket.send(pickle.dumps(inputs))
            data = client_socket.recv(1024)
            all_positions = pickle.loads(data)
            # Обновляем позиции
            player_x = all_positions['server']['x']
            player_y = all_positions['server']['y']
            players = {k: v for k, v in all_positions.items() if k != 'server'}
        except:
            running = False
    else:
        # Управление персонажем для сервера или одиночной игры
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player_x -= player_speed
        if keys[pygame.K_RIGHT]:
            player_x += player_speed
        if keys[pygame.K_UP]:
            player_y -= player_speed
        if keys[pygame.K_DOWN]:
            player_y += player_speed

        # Проверяем, чтобы персонаж не выходил за пределы карты
        player_x = max(0, min(player_x, map_width - sprite_rect.width))
        player_y = max(0, min(player_y, map_height - sprite_rect.height))

    # Синхронизация камеры с положением персонажа
    camera_x = max(0, min(player_x - (width // 2), map_width - width))
    camera_y = max(0, min(player_y - (height // 2), map_height - height))

    # Отрисовка карты
    screen.fill((0, 0, 0))  # Очистка экрана
    draw_map(screen, camera_x, camera_y)

    # Отрисовка спрайта сервера
    screen.blit(sprite, (player_x - camera_x, player_y - camera_y))

    # Отрисовка других игроков
    for pid, pos in players.items():
        screen.blit(sprite, (pos['x'] - camera_x, pos['y'] - camera_y))
    
    pygame.display.flip()  # Обновление экрана

if server_socket:
    server_socket.close()
if client_socket:
    client_socket.close()
pygame.quit()
