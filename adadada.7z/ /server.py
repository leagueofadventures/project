import socket
import threading
import pickle
import sys

# Размеры экрана (фиксированные для сервера)
width = 1920
height = 1080

# Размеры карты (примерные)
map_width = 10000
map_height = 10000

# Позиция персонажа сервера (фиксированная или управляемая)
player_x = width // 2
player_y = height // 2
player_speed = 5

# Мультиплеер переменные
players = {}  # {client_id: {'x': x, 'y': y}}
client_id = 0
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('0.0.0.0', 5555))
server_socket.listen(5)
print("Сервер запущен на порту 5555")

def handle_client(client_sock, addr):
    global client_id
    cid = client_id
    client_id += 1
    players[cid] = {'x': width // 2, 'y': height // 2}
    print(f"Клиент {cid} подключен: {addr}")
    try:
        while True:
            data = client_sock.recv(1024)
            if not data:
                break
            inputs = pickle.loads(data)
            # Обновляем позицию клиента
            if inputs['left']:
                players[cid]['x'] -= player_speed
            if inputs['right']:
                players[cid]['x'] += player_speed
            if inputs['up']:
                players[cid]['y'] -= player_speed
            if inputs['down']:
                players[cid]['y'] += player_speed
            # Ограничиваем позицию
            players[cid]['x'] = max(0, min(players[cid]['x'], map_width))
            players[cid]['y'] = max(0, min(players[cid]['y'], map_height))
            # Отправляем все позиции
            all_positions = {'server': {'x': player_x, 'y': player_y}}
            all_positions.update(players)
            client_sock.send(pickle.dumps(all_positions))
            print(f"Позиции: {all_positions}")
    except Exception as e:
        print(f"Ошибка с клиентом {cid}: {e}")
    print(f"Клиент {cid} отключен")
    del players[cid]
    client_sock.close()

def server_loop():
    while True:
        try:
            client_sock, addr = server_socket.accept()
            threading.Thread(target=handle_client, args=(client_sock, addr)).start()
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Ошибка сервера: {e}")

print("Сервер запущен. Нажмите Ctrl+C для остановки.")
try:
    server_loop()
except KeyboardInterrupt:
    print("Сервер остановлен.")

server_socket.close()
