<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="набор тайлов" tilewidth="64" tileheight="64" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="трава (2).jpg" width="64" height="64"/>
 </tile>
 <tile id="1">
  <image source="дерево.jpg" width="64" height="64"/>
 </tile>
 <tile id="2">
  <image source="камень.png" width="64" height="64"/>
 </tile>
 <tile id="5">
  <image source="пруд (1) (1).jpg" width="64" height="64"/>
 </tile>
 <tile id="6">
  <image source="resize_image_9de4b8ad2f41828f425df208946f4f67_67bd6fa3e07ae.png" width="64" height="64"/>
 </tile>
</tileset>
