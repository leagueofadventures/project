import pygame
import pytmx
from pytmx import util_pygame
import socket
import pickle
import sys
import json
import os
import argparse
from enhanced_detection import get_client_config, detector

# Определяем текущую директорию проекта
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Парсинг аргументов командной строки
parser = argparse.ArgumentParser(description='Игровой клиент')
parser.add_argument('--interface', '-i', type=str, help='Выбрать конкретный сетевой интерфейс')
parser.add_argument('--list-interfaces', '-l', action='store_true', help='Показать все доступные интерфейсы')
parser.add_argument('--server', '-s', type=str, help='Адрес сервера для подключения')
parser.add_argument('--port', '-p', type=int, default=5555, help='Порт сервера (по умолчанию 5555)')
parser.add_argument('--auto', '-a', action='store_true', help='Автоматический режим без интерактивного ввода')

args = parser.parse_args()

# Если запрошено показать интерфейсы
if args.list_interfaces:
    detector.print_available_interfaces()
    sys.exit(0)

# Если не выбран автоматический режим и не указан сервер, показать интерфейсы и предложить выбор
if not args.auto and not args.server:
    print("\n=== ДОСТУПНЫЕ СЕТЕВЫЕ ИНТЕРФЕЙСЫ ===")
    interfaces = detector.get_all_interfaces()
    vpn_interfaces = detector.detect_vpn_interfaces(interfaces)

    if vpn_interfaces:
        print("\n🔥 VPN интерфейсы (рекомендуется):")
        for i, interface in enumerate(vpn_interfaces, 1):
            ip = interface.get('ip', 'N/A')
            name = interface.get('name', 'Unknown')
            interface_type = interface.get('type', 'unknown')
            print(f"  {i}. {name} - {ip} [{interface_type}]")

    print("\n🌐 Все интерфейсы:")
    for i, interface in enumerate(interfaces, len(vpn_interfaces) + 1):
        ip = interface.get('ip', 'N/A')
        name = interface.get('name', 'Unknown')
        print(f"  {i}. {name} - {ip}")

    # Предлагаем выбор
    choice = input(f"\nВыберите номер интерфейса (1-{len(interfaces)}) или введите IP сервера вручную: ").strip()

    if choice.isdigit():
        choice_num = int(choice) - 1
        if 0 <= choice_num < len(interfaces):
            selected_interface = interfaces[choice_num]
            if 'ip' in selected_interface:
                args.server = selected_interface['ip']
                print(f"✅ Выбран: {selected_interface.get('name', 'Unknown')} - {args.server}")
            else:
                print("❌ Выбранный интерфейс не имеет IP-адреса")
        else:
            print("❌ Неверный номер интерфейса")
    else:
        # Пользователь ввел IP вручную
        args.server = choice
        print(f"✅ Выбран сервер: {args.server}")

    print(f"\n🔌 Подключение к {args.server}:{args.port}")
    input("Нажмите Enter для продолжения...")

# Инициализация Pygame
pygame.init()
pygame.display.init()

# Полноэкранный режим
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

# Получение размеров экрана
info = pygame.display.Info()
width, height = info.current_w, info.current_h

# Загрузка TMX-карты
map_file = os.path.join(PROJECT_DIR, 'Карта', 'maps', 'безымянный.tmx')
try:
    tmx_data = util_pygame.load_pygame(map_file)
    map_width = tmx_data.width * tmx_data.tilewidth
    map_height = tmx_data.height * tmx_data.tileheight
except Exception as e:
    print(f"Ошибка загрузки карты: {e}")
    pygame.quit()
    sys.exit()

# Камера
camera_x = 0
camera_y = 0
camera_speed = 10

# Загрузка спрайта
sprite_path = os.path.join(PROJECT_DIR, 'Карта', 'sprites', 'lena.jpg')
try:
    sprite = pygame.image.load(sprite_path)
    sprite_rect = sprite.get_rect(center=(width // 2, height // 2))
except Exception as e:
    print(f"Ошибка загрузки спрайта: {e}")
    pygame.quit()
    sys.exit()

# Позиция персонажа
player_x = width // 2
player_y = height // 2
player_speed = 5

# Мультиплеер переменные
players = {}

# Получить конфигурацию клиента с автоопределением
if args.server:
    # Если указан сервер вручную
    client_config = {
        'server_host': args.server,
        'server_port': args.port
    }
else:
    # Автоопределение
    client_config = get_client_config(args.interface)

server_host = client_config['server_host']
server_port = args.port if args.server else int(client_config['server_port'])

print(f"Попытка подключения к {server_host}:{server_port}")

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    client_socket.connect((server_host, server_port))
    print("Успешно подключено к серверу")
except Exception as e:
    print(f"Не удалось подключиться к серверу: {e}")
    print("Убедитесь, что сервер запущен и доступен")
    print("Попробуйте:")
    print("1. python client.py --list-interfaces  # Посмотреть доступные интерфейсы")
    print("2. python client.py --interface 'Radmin VPN'  # Выбрать интерфейс Radmin")
    print("3. python client.py --server 192.168.1.100  # Подключиться к конкретному серверу")
    pygame.quit()
    sys.exit()

def draw_map(surface, camera_x, camera_y):
    for layer in tmx_data.visible_layers:
        if isinstance(layer, pytmx.TiledTileLayer):
            for x, y, gid in layer:
                tile = tmx_data.get_tile_image_by_gid(gid)
                if tile:
                    surface.blit(tile, (x * tmx_data.tilewidth - camera_x,
                                        y * tmx_data.tileheight - camera_y))

running = True
while running:
    clock = pygame.time.Clock()
    clock.tick(60)

    # Обработка событий
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    # Отправляем вводы на сервер
    keys = pygame.key.get_pressed()
    inputs = {
        'left': keys[pygame.K_LEFT],
        'right': keys[pygame.K_RIGHT],
        'up': keys[pygame.K_UP],
        'down': keys[pygame.K_DOWN]
    }
    try:
        client_socket.send(pickle.dumps(inputs))
        data = client_socket.recv(1024)
        all_positions = pickle.loads(data)
        # Обновляем позиции
        if 'server' in all_positions and isinstance(all_positions['server'], dict):
            player_x = all_positions['server'].get('x', width // 2)
            player_y = all_positions['server'].get('y', height // 2)
        
        # Обновляем позиции других игроков
        if 'players' in all_positions:
            players = all_positions['players']
        else:
            players = {k: v for k, v in all_positions.items() if k != 'server' and k != 'server_time'}
    except Exception as e:
        print(f"Ошибка соединения: {e}")
        running = False

    # Синхронизация камеры с положением персонажа
    camera_x = max(0, min(player_x - (width // 2), map_width - width))
    camera_y = max(0, min(player_y - (height // 2), map_height - height))

    # Отрисовка карты
    screen.fill((0, 0, 0))
    draw_map(screen, camera_x, camera_y)

    # Отрисовка спрайта сервера
    screen.blit(sprite, (player_x - camera_x, player_y - camera_y))

    # Отрисовка других игроков
    for pid, pos in players.items():
        screen.blit(sprite, (pos['x'] - camera_x, pos['y'] - camera_y))
    
    pygame.display.flip()

client_socket.close()
pygame.quit()
