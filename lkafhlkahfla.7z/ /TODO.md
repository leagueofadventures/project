# TODO: Add Multiplayer to Game

- [x] Import necessary modules: socket, threading, pickle for data serialization
- [x] Add command line argument to choose server or client mode
- [x] Implement server logic: listen for connections, handle multiple clients
- [x] Implement client logic: connect to server, send inputs, receive updates
- [x] Modify game loop to integrate networking
- [x] Sync player positions between server and clients
- [x] Test multiplayer by running server and client instances
- [x] Split project into server.py and client.py
